package customersmanagementgui;

import customersmanagementgui.*;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

public class CustomersDAO {

    public static void insertCutomer(int id, String name, String email, int mobile) {
        String insertSQL = String.format("INSERT INTO Customer (ID, Name, Email, Mobile) VALUES ('%s', '%s', '%s', '%s');",
                id, name, email, mobile);
        int count = DBUtils.executeUpdate(insertSQL);

        if (count == 0) {
            System.out.println("!!! Failed to add a new Customer!!!");
        } else {
            System.out.println("\n>>> A New Customer Success Added!!!");
        }
    }

    public static void deleteCustomerByID(int id) {
        String deleteSQL = "DELETE FROM Customer WHERE ID ='" + id + "';";
        int count = DBUtils.executeUpdate(deleteSQL);

        if (count == 0) {
            System.out.println("!!! Customer NOT found!!!");
        } else {
            System.out.println("\n>>> Customer SuccessFully Deleted!!!");
        }
    }

    public static Customers searchCustomerByID(int id) {
        String query = "SELECT * FROM Customer WHERE ID = " + id + ";";
        Customers c = null;

        try {
            ResultSet rs = DBUtils.executeQuery(query);

            if (rs.next()) {
                c = new Customers();
                c.setId(rs.getInt("ID"));
                c.setName(rs.getString("Name"));
                c.setEmail(rs.getString("Email"));
                c.setMobile(rs.getInt("Mobile"));
            }
        } catch (SQLException ex) {
            System.out.println("SQLException on executeQuery: " + ex.getMessage());
        }
        return c;
    }

    public static ArrayList<Customers> getAllCustomer() {
        String query = "SELECT * FROM Customer;";
        ArrayList<Customers> customer = new ArrayList<>();

        try {
            ResultSet rs = DBUtils.executeQuery(query);

            while (rs.next()) {
                Customers c = new Customers();
                c.setId(rs.getInt("ID"));
                c.setName(rs.getString("Name"));
                c.setEmail(rs.getString("Email"));
                c.setMobile(rs.getInt("Mobile"));
                customer.add(c);
            }
        } catch (SQLException ex) {
            System.out.println("SQLException on executeQuery: " + ex.getMessage());
        }
        return customer;
    }

    public static void insertCustomer(String name, String email, int mobile) throws ClassNotFoundException, Exception {
        String sql = "insert into customer (Name, Email, Mobile) values ('" + name + "', '" + email + "', '" + mobile + "');";

        try {
            DBUtils.executeUpdate(sql);
        } catch (Exception e) {
            System.out.println("Exception occur while inserting the data " + e);
            e.printStackTrace();
            throw e;
        }
    }

    public static void updateCustomer(int id, String name, String email, int mobile) throws SQLException, ClassNotFoundException {
        String sql = "update Customer set Name = '" + name + "', Email = '" + email + "', Mobile = '" + mobile + "' where ID = '" + id + "' ";

        try {
            DBUtils.executeUpdate(sql);
        } catch (Exception e) {
            System.out.println("Error occured while updating the record!");
            e.printStackTrace();
            throw e;
        }
    }

    public static ObservableList<Customers> getAllCustomers() throws ClassNotFoundException, Exception {
        String sql = "select * from Customer";

        try {
            ResultSet rsSet = DBUtils.executeQuery(sql);
            ObservableList<Customers> customerList = getCustomerObjects(rsSet);
            return customerList;
        } catch (Exception e) {
            System.out.println("Error occured while fetching the records from DB" + e);
            e.printStackTrace();
            throw e;
        }
    }

    private static ObservableList<Customers> getCustomerObjects(ResultSet rsSet) throws Exception {
        try {
            ObservableList<Customers> customerList = FXCollections.observableArrayList();

            while (rsSet.next()) {
                Customers customer = new Customers();
                customer.setId(rsSet.getInt("ID"));
                customer.setName(rsSet.getString("Name"));
                customer.setEmail(rsSet.getString("Email"));
                customer.setMobile(rsSet.getInt("Mobile"));
                customerList.add(customer);
            }
            return customerList;
        } catch (Exception e) {
            System.out.println("Error occurred while fetching data from DB" + e);
            e.printStackTrace();
            throw e;
        }
    }

    public static ObservableList<Customers> searchCustomer(String customerId) throws ClassNotFoundException, Exception {
        String sql = "select * from Customer where ID = " + customerId;
        try {
            ResultSet rsSet = DBUtils.executeQuery(sql);
            ObservableList<Customers> customerList = getCustomerObjects(rsSet);
            return customerList;
        } catch (Exception e) {
            System.out.println("Error occured while searching records: " + e);
            e.printStackTrace();
            throw e;
        }
    }

    public static void reCreateCustomers() throws ClassNotFoundException {
        CreateDatabases.createCustomerDB();

    }

}