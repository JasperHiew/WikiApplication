package customersmanagementgui;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class CreateDatabases {
 
    public static void createCustomerDB() {
        String url = "jdbc:mysql://localhost:3306/"; // no database yet
        String user = "root";
        String password = "";
        
        Connection con = null;
        Statement stmt = null;
        String query;
        ResultSet result = null;  
        
        try {
            con = DriverManager.getConnection(url, user, password);
            stmt = con.createStatement();
            
            System.out.println("\n##############################");
            System.out.println(" Database is being created...");
            System.out.println("##############################\n");
            query = "DROP DATABASE IF EXISTS smtbiz";
            stmt.executeQuery(query);
            query = "CREATE DATABASE smtbiz";
            stmt.executeQuery(query);
            query = "USE smtbiz";
            stmt.executeQuery(query);
            query = """
                    CREATE TABLE Customer (
                    ID INTEGER NOT NULL AUTO_INCREMENT,
                    Name VARCHAR(32),
                    Email VARCHAR(32),
                    Mobile INTEGER,
                    PRIMARY KEY (ID)
                    );
                    """;
            stmt.executeQuery(query);
            query = """
                    INSERT INTO Customer
                        (ID, Name, Email, Mobile)
                    VALUES
                        (1, "Jasper", "jasper34@gmail.com", 01231233),
                        (2, "Candaces", "candace521@gmail.com", 04645665),
                        (3, "Kyle", "kwatson@gmail.com", 01231231),
                        (4, "Kirsten", "K12@gmail.com", 05838553),
                        (5, "Kristen", "kris@gmail.com", 2131312);
                    """;
            stmt.executeQuery(query);
            query = "SELECT * FROM Customer;";
            result = stmt.executeQuery(query); // execute the SQL query
        } catch (SQLException ex) {
            System.out.println("SQLException on database creation: " + ex.getMessage());
        } finally {
            try {
                if (result != null) {
                    result.close();
                }
                
                if (stmt != null) {
                    stmt.close();
                }
                
                if (con != null) {
                    con.close();
                }
            } catch (SQLException ex) {
                System.out.println("SQLException caught: " + ex.getMessage());
            }
        }
    }
}

