package customersmanagementgui;

//import com.mysql.cj.conf.IntegerProperty;
//import com.mysql.cj.conf.StringProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.StringProperty;



public class Customers {
    
    private IntegerProperty idProperty;
    private StringProperty nameProperty;
    private StringProperty emailProperty;
    private IntegerProperty mobileProperty;
    
    private int id;
    private String name;
    private String email;
    private int mobile;
    
    public Customers() {
        this.idProperty = new SimpleIntegerProperty();
        this.nameProperty = new SimpleStringProperty();
        this.emailProperty = new SimpleStringProperty();
        this.mobileProperty = new SimpleIntegerProperty();
    
    }
    
    
    public Customers (int id, String name, String email, int mobile) {
        this.id = id;
        this.name = name;
        this.email = email;
        this.mobile = mobile;
    }

    /**
     * @return the id
     */
    public int getId() {
        //return id;
        return idProperty.get();
    }

    /**
     * @param id the id to set
     */
    public void setId(int id) {
        //this.id = id;
        this.idProperty.set(id);
    }
    
    public IntegerProperty getCustomerId() {
        return idProperty;
    }

    /**
     * @return the name
     */
    public String getName() {
        //return name;
        return nameProperty.get();
    }

    /**
     * @param name the name to set
     */
    public void setName(String name) {
        //this.name = name;
        this.nameProperty.set(name);
    }

    public StringProperty getCustomerName() {
        return nameProperty;
    }
    
    /**
     * @return the email
     */
    public String getEmail() {
        //return email;
        return emailProperty.get();
    }

    /**
     * @param email the email to set
     */
    public void setEmail(String email) {
        //this.email = email;
        this.emailProperty.set(email);
    }

    public StringProperty getCustomerEmail () {
        return emailProperty;
    }
    /**
     * @return the mobile
     */
    public int getMobile() {
        //return mobile;
        return mobileProperty.get();
    }

    /**
     * @param mobile the mobile to set
     */
    public void setMobile(int mobile) {
       // this.mobile = mobile;
       this.mobileProperty.set(mobile);         
    }
    
    public IntegerProperty getCustomerMobile() {
        return mobileProperty;
    }
}
