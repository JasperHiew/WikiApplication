package customersmanagementgui;

import customersmanagementgui.*;
import java.awt.event.MouseEvent;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;

public class CustomersManagementController {

    @FXML
    private Button addButton;

    @FXML
    private Button delButton;

    @FXML
    private TableColumn<Customers, String> emailTable;

    @FXML
    private TextField emailText;

    @FXML
    private TextField emailText2;

    @FXML
    private Button fillButton;

    @FXML
    private TableColumn<Customers, Integer> idTable;

    @FXML
    private TextField idText;

    @FXML
    private TextField idText2;

    @FXML
    private TableColumn<Customers, String> mobileTable;

    @FXML
    private TextField mobileText;

    @FXML
    private TextField mobileText2;

    @FXML
    private TableColumn<Customers, String> nameTable;

    @FXML
    private TextField nameText;

    @FXML
    private TextField nameText2;

    @FXML
    private Button searchButton;

    @FXML
    private TableView<Customers> table;

    @FXML
    private Button updateButton;

    int index = -1;

    ObservableList<Customers> customer = FXCollections.observableArrayList();

    @FXML
    void fillHandle(ActionEvent event) throws Exception {
        try {
        CustomersDAO.reCreateCustomers();
        CreateDatabases.createCustomerDB();
        
        ObservableList<Customers> customerList = CustomersDAO.getAllCustomers();
        populateTable(customerList);
        table.setItems(customerList);
        } catch  (Exception e) {
            System.out.println(e);
        }
//        try {
//            CustomerDAO.reCreateCustomers();
//            ObservableList<Customer> customerList = CustomerDAO.getAllCustomers();
//            populateTable(customerList);
//        } catch (Exception e) {
//            System.out.println(e);
//            e.printStackTrace();
//            throw e;
//        }
    }

    @FXML
    void addHandle(ActionEvent event) throws ClassNotFoundException, Exception {
        try {
            CustomersDAO.insertCustomer(nameText.getText(), emailText.getText(), Integer.parseInt(mobileText.getText()));
            ObservableList<Customers> customerList = CustomersDAO.getAllCustomers();
            populateTable(customerList);
        } catch (Exception e) {
            System.out.println("Exception occur in Insertion " + e);
            e.printStackTrace();
            throw e;
        }
        clearTexts();
    }

    @FXML
    void delHandle(ActionEvent event) throws Exception {
        if (!idText.getText().trim().isEmpty()) {
            CustomersDAO.deleteCustomerByID(Integer.parseInt(idText.getText()));
            ObservableList<Customers> customerList = CustomersDAO.getAllCustomers();
            populateTable(customerList);
        } else {
            System.out.println("Nothing has been inputted into the text field.");
        }
        clearTexts();
    }

    @FXML
    void searchHandle(ActionEvent event) throws Exception {
//        if (!idText.getText().trim().isEmpty()) {
//            CustomerDAO.searchCustomerByID(Integer.parseInt(idText.getText()));
//        } else {
//            System.out.println("Nothing has been inputted into the text field.");
//        }
        ObservableList<Customers> customerList = CustomersDAO.searchCustomer(idText.getText());
        if (customerList.size() > 0) {
            //populateTable(customerList);
            System.out.println("Record found");
        } else {
            System.out.println("Record NOT found");
        }
        clearTexts();
    }

    @FXML
    void updateHandle(ActionEvent event) throws ClassNotFoundException, Exception {
        try {
            CustomersDAO.updateCustomer(Integer.parseInt(idText2.getText()), nameText2.getText(), emailText2.getText(), Integer.parseInt(mobileText2.getText()));
            ObservableList<Customers> customerList = CustomersDAO.getAllCustomers();
            populateTable(customerList);
        } catch (Exception e) {
            System.out.println("Please fill in the bottom name, email and mobile boxes of which id you want to change.");
            e.printStackTrace();
            throw e;
        }
        clearTexts();
//    ObservableList<Customer> customerList = table.getItems();
//    int currentId = Integer.parseInt(idText2.getText());
//    
//    for (Customer table : customerList) {
//        if (table.getCustomerId().equals(currentId)) {
//            table.setName(nameText2.getText());
//            table.setEmail(emailText2.getText());
//            table.setMobile(Integer.parseInt(mobileText2.getText()));
//            
//          
//           // break;
//        }
//    }

    }

    @FXML
    private void initialize() throws Exception {
        idTable.setCellValueFactory(cellData -> cellData.getValue().getCustomerId().asObject());
        nameTable.setCellValueFactory(cellData -> cellData.getValue().getCustomerName());
        emailTable.setCellValueFactory(cellData -> cellData.getValue().getCustomerEmail());
        mobileTable.setCellValueFactory(new PropertyValueFactory<Customers, String>("Mobile"));
        ObservableList<Customers> customerList = CustomersDAO.getAllCustomers();
        populateTable(customerList);
    }

    private void populateTable(ObservableList<Customers> customerList) {
        table.setItems(customerList);
    }

    private void clearTexts() {
        idText.clear();
        nameText.clear();
        emailText.clear();
        mobileText.clear();
        idText2.clear();
        nameText2.clear();
        emailText2.clear();
        mobileText2.clear();
    }
    
    
    @FXML
    void tableClick(MouseEvent event) throws Exception {

    }

    private void setupTable() {

    }
}
